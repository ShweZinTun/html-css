<?php

$txt="Hello World!";
echo $txt;
echo '<br>';
echo "My first PHP script! <br>";
$x=45;
$y=70;
$res=$x+$y;
echo 'The result is '.$res.'<br>';

$i=5985;
var_dump($i);
echo '<br>';
//string
echo strlen("Hello World!");
echo '<br>';

echo str_word_count("Hello World!").'<br>';

echo strpos("hello world!","world");

$x=6754;
var_dump(is_int($x));

$x=67.54;
var_dump(is_int($x));

?> 
